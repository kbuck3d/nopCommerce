﻿using Nop.Core.Domain.Attributes;

namespace Nop.Core.Domain.Common;

/// <summary>
/// Represents an address attribute
/// </summary>
public partial class AddressAttribute : BaseAttribute
{
}