﻿using Nop.Core.Domain.Attributes;

namespace Nop.Core.Domain.Common;

/// <summary>
/// Represents an address attribute value
/// </summary>
public partial class AddressAttributeValue : BaseAttributeValue
{
}