﻿using Nop.Core.Domain.Attributes;

namespace Nop.Core.Domain.Customers;

/// <summary>
/// Represents a customer attribute
/// </summary>
public partial class CustomerAttribute : BaseAttribute
{
}