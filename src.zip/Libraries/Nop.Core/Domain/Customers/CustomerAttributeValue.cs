﻿using Nop.Core.Domain.Attributes;

namespace Nop.Core.Domain.Customers;

/// <summary>
/// Represents a customer attribute value
/// </summary>
public partial class CustomerAttributeValue : BaseAttributeValue
{
}